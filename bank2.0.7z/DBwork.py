from People import Customer
from People import Bill
import pymysql


class DBwork:
    def __init__(self, db=None, cursor=None):
        self.db = db
        self.cursor = cursor

    def DBcon(self, clist, blist):
        try:
            self.db = pymysql.connect("localhost", "root", "19980905yxy", "bank")
            self.cursor = self.db.cursor()
        except:
            print('数据库连接失败')
        self.cursor.execute("select * from bill")
        data = self.cursor.fetchall()
        for row in data:
            bills = Bill()
            bills.pid = row[0]
            bills.sa_dr = row[1]
            bills.date = row[2]
            bills.total = row[3]
            blist.append(bills)
        self.cursor.execute("select * from people")
        data = self.cursor.fetchall()
        for row in data:
            cuss = Customer()
            cuss.pid = row[0]
            cuss.password = row[1]
            cuss.name = row[2]
            cuss.identity = row[3]
            cuss.phone = row[4]
            cuss.total = row[5]
            cuss.pflag = row[6]
            clist.append(cuss)

    def DBjoin(self, new_cus):
        sqljoin = "insert into people(pid, password, name, identity, phone, total, pflag)" \
              "values('%s', '%s', '%s', '%s', '%s',  '%lf', '%d')" % \
              (new_cus.pid, new_cus.password, new_cus.name, new_cus.identity, new_cus.phone, new_cus.total, new_cus.pflag)
        try:
            # 执行SQL语句
            self.cursor.execute(sqljoin)
            # 提交到数据库执行
            self.db.commit()
        except:
            # 发生错误时回滚
            self.db.rollback()

    def DBcum(self, cum):
        sql = "update people " \
              "set password =  '%s', name = '%s', identity = '%s', phone = '%s', total = '%lf'" \
              "where pid = '%s'" % (cum.password, cum.name, cum.identity, cum.phone, cum.total, cum.pid)
        try:
            # 执行SQL语句
            self.cursor.execute(sql)
            # 提交到数据库执行
            self.db.commit()
        except:
            # 发生错误时回滚
            self.db.rollback()

    def DBbill(self,nbill):
        sqlb = "insert into bill(pid, sa_dr, date, total)" \
               "values('%s', '%s', '%s','%lf' )" % \
               (nbill.pid, nbill.sa_dr, nbill.date, nbill.total)
        try:
            # 执行SQL语句
            self.cursor.execute(sqlb)
            # 提交到数据库执行
            self.db.commit()
        except:
            # 发生错误时回滚
            self.db.rollback()

    def DBdelcum(self,cum):
        sqldc = "delete from people where pid =  '%s'" % (cum.pid)
        sqldb = "delete from bill where pid = '%s'" % (cum.pid)
        try:
            # 执行SQL语句
            self.cursor.execute(sqldc)
            # 提交到数据库执行
            self.db.commit()
        except:
            # 发生错误时回滚
            self.db.rollback()
        try:
            # 执行SQL语句
            self.cursor.execute(sqldb)
            # 提交到数据库执行
            self.db.commit()
        except:
            # 发生错误时回滚
            self.db.rollback()

    def DBdelBill(self, cum):
        sqldb = "delete from bill where pid = '%s'" % (cum.pid)
        try:
            # 执行SQL语句
            self.cursor.execute(sqldb)
            # 提交到数据库执行
            self.db.commit()
        except:
            # 发生错误时回滚
            self.db.rollback()