# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'upline.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
from CustomerPage import *
from HostPage import *
from Join_h import *
from People import Host
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QDialog,QMessageBox
from DBwork import DBwork
import sys


class Ui_Dialog(QDialog):
    def __init__(self, clist = None, blist = None, host = None, customer = None):
        super(Ui_Dialog, self).__init__()
        self.setupUi(self)
        self.clist = clist
        self.blist = blist
        self.host = host
        self.customer = customer

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(415, 215)
        self.lineEdit = QtWidgets.QLineEdit(Dialog)
        self.lineEdit.setGeometry(QtCore.QRect(100, 30, 261, 31))
        self.lineEdit.setObjectName("lineEdit")

        self.lineEdit_2 = QtWidgets.QLineEdit(Dialog)
        self.lineEdit_2.setGeometry(QtCore.QRect(100, 80, 261, 31))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.lineEdit_2.setEchoMode(QtWidgets.QLineEdit.Password)

        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(80, 160, 75, 23))
        self.pushButton.setObjectName("pushButton")

        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(260, 160, 75, 23))
        self.pushButton_2.setObjectName("pushButton_2")

        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 32, 54, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setObjectName("label")

        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(20, 79, 41, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")

        self.retranslateUi(Dialog)
        self.pushButton.clicked.connect(Dialog.upline_y)
        self.pushButton_2.clicked.connect(Dialog.join)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "欢迎使用银行服务系统"))
        self.pushButton.setText(_translate("Dialog", "登录"))
        self.pushButton_2.setText(_translate("Dialog", "注册"))
        self.label.setText(_translate("Dialog", "用户名"))
        self.label_2.setText(_translate("Dialog", "密码"))

    def upline_y(self):
        pid = self.lineEdit.text()
        password = self.lineEdit_2.text()
        for cus in self.clist:
            if cus.pflag == 1 and pid == cus.pid and password == cus.password:
                #QMessageBox.information(self, "欢迎", "欢迎您,亲爱的用户！", QMessageBox.Yes)
                #self.usrLineEdit.setFocus()
                CustomerPage.customer = cus
                CustomerPage.show()
                self.close()
                return
            elif cus.pflag == 0 and pid == cus.pid and password == cus.password:
                #QMessageBox.information(self, "欢迎", "欢迎您,管理员!" , QMessageBox.Yes)
                #self.usrLineEdit.setFocus()
                self.host = Host(pid, password, 0)
                HostPage.host = self.host
                HostPage.show()
                self.close()
                return
        QMessageBox.warning(self, "警告", "用户名或密码错误！", QMessageBox.Yes)

    def join(self):
        JoinPage.show()


if __name__ == '__main__':
    clist = list()
    blist = list()
    DBw = DBwork()
    DBw.DBcon(clist, blist)
    app = QtWidgets.QApplication(sys.argv)
    window = Ui_Dialog(clist, blist)
    JoinPage = Ui_Join(DBw, clist)
    HostPage = Ui_HostPage(DBw, clist, blist, window.host)
    CustomerPage = Ui_CustomerPage(DBw, clist, blist, window.customer)
    window.show()
    sys.exit(app.exec_())