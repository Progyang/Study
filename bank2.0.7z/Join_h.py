# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Join_h.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox, QDialog
from People import Customer
import sys


class Ui_Join(QDialog):
    def __init__(self,DBw = None, clist = None):
        super(Ui_Join, self).__init__()
        self.setupUi(self)
        self.DBw = DBw
        self.clist = clist
        self.new_pidt = None
        self.new_past = None
        self.new_pas1t = None
        self.new_namet = None
        self.new_identityt = None
        self.new_phonet = None

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 300)
        self.formLayoutWidget = QtWidgets.QWidget(Dialog)
        self.formLayoutWidget.setGeometry(QtCore.QRect(10, 10, 371, 231))
        self.formLayoutWidget.setObjectName("formLayoutWidget")
        self.formLayout = QtWidgets.QFormLayout(self.formLayoutWidget)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.formLayout.setObjectName("formLayout")
        self.label = QtWidgets.QLabel(self.formLayoutWidget)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.LabelRole, self.label)
        self.new_pid = QtWidgets.QLineEdit(self.formLayoutWidget)
        self.new_pid.setObjectName("new_pid")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.FieldRole, self.new_pid)
        self.label_2 = QtWidgets.QLabel(self.formLayoutWidget)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.LabelRole, self.label_2)
        self.new_pas = QtWidgets.QLineEdit(self.formLayoutWidget)
        self.new_pas.setObjectName("new_pas")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.FieldRole, self.new_pas)
        self.label_3 = QtWidgets.QLabel(self.formLayoutWidget)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.formLayout.setWidget(2, QtWidgets.QFormLayout.LabelRole, self.label_3)
        self.new_pas1 = QtWidgets.QLineEdit(self.formLayoutWidget)
        self.new_pas1.setObjectName("new_pas1")
        self.formLayout.setWidget(2, QtWidgets.QFormLayout.FieldRole, self.new_pas1)
        self.label_4 = QtWidgets.QLabel(self.formLayoutWidget)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.formLayout.setWidget(3, QtWidgets.QFormLayout.LabelRole, self.label_4)
        self.new_name = QtWidgets.QLineEdit(self.formLayoutWidget)
        self.new_name.setObjectName("new_name")
        self.formLayout.setWidget(3, QtWidgets.QFormLayout.FieldRole, self.new_name)
        self.label_5 = QtWidgets.QLabel(self.formLayoutWidget)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_5.setFont(font)
        self.label_5.setObjectName("label_5")
        self.formLayout.setWidget(4, QtWidgets.QFormLayout.LabelRole, self.label_5)
        self.new_identity = QtWidgets.QLineEdit(self.formLayoutWidget)
        self.new_identity.setObjectName("new_identity")
        self.formLayout.setWidget(4, QtWidgets.QFormLayout.FieldRole, self.new_identity)
        self.label_6 = QtWidgets.QLabel(self.formLayoutWidget)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.formLayout.setWidget(5, QtWidgets.QFormLayout.LabelRole, self.label_6)
        self.new_phone = QtWidgets.QLineEdit(self.formLayoutWidget)
        self.new_phone.setObjectName("new_phone")
        self.formLayout.setWidget(5, QtWidgets.QFormLayout.FieldRole, self.new_phone)
        self.horizontalLayoutWidget = QtWidgets.QWidget(Dialog)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(9, 260, 371, 31))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.conform = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.conform.setObjectName("conform")
        self.horizontalLayout.addWidget(self.conform)
        self.cancel = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.cancel.setObjectName("cancel")
        self.horizontalLayout.addWidget(self.cancel)

        self.retranslateUi(Dialog)
        self.conform.clicked.connect(Dialog.join)
        self.cancel.clicked.connect(Dialog.disjoin)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "注册"))
        self.label.setText(_translate("Dialog", "注册用账号"))
        self.label_2.setText(_translate("Dialog", "注册用密码"))
        self.label_3.setText(_translate("Dialog", "再输一遍"))
        self.label_4.setText(_translate("Dialog", "姓名"))
        self.label_5.setText(_translate("Dialog", "身份证号"))
        self.label_6.setText(_translate("Dialog", "手机号"))
        self.conform.setText(_translate("Dialog", "确认"))
        self.cancel.setText(_translate("Dialog", "取消"))

    def join(self):

        self.new_pidt = self.new_pid.text()
        self.new_past = self.new_pas.text()
        self.new_pas1t = self.new_pas1.text()
        self.new_namet = self.new_name.text()
        self.new_identityt = self.new_identity.text()
        self.new_phonet = self.new_phone.text()
        #print(self.new_namet)
        #print(self.new_pidt)
        for com in self.clist:
            if self.new_pidt == com.pid:
                QMessageBox.warning(self, "警告", "已有账户,请重新输入！", QMessageBox.Yes)
                self.new_pid.clear()
                return
        if self.new_past != self.new_pas1t:
            QMessageBox.warning(self, "警告", "两次密码不一致!请重新输入!", QMessageBox.Yes)
            self.new_pas.clear()
            self.new_pas1.clear()
        else:
            if self.new_namet == '' and self.new_identityt == '' and self.new_phonet == '':
                QMessageBox.warning(self, "警告", "有项目未填!请输入!", QMessageBox.Yes)
            else:
                new_cus = Customer(self.new_pidt, self.new_past, self.new_namet, self.new_identityt, self.new_phonet, 0, 1)
                self.clist.append(new_cus)
                self.DBw.DBjoin(new_cus)
                QMessageBox.information(self, "成功", "欢迎您,新用户!", QMessageBox.Yes)
                self.close()
                return

    def disjoin(self):
        self.close()

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = Ui_Join()
    window.show()
    sys.exit(app.exec_())
