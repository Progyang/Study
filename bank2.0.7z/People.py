import datetime
from PyQt5.QtWidgets import QMessageBox
from PyQt5 import QtWidgets

class People:
    def __init__(self=None, pid=None, password=None, pflag=None):
        self.pid = pid
        self.password = password
        # 标记,0代表管理员,1代表客户
        self.pflag = pflag


class Bill:
    def __init__(self, pid=None, sa_dr=None, date=None, total=None):
        self.pid = pid
        self.sa_dr = sa_dr
        self.date = date
        self.total = total

    def show(self):
        print(self.pid, self.sa_dr, self.date, self.total)


class Customer(People):
    def __init__(self, pid=None, password=None, name=None, identity=None, phone=None, total=None, pflag=None):
        People.__init__(self, pid, password, pflag)
        self.name = name
        self.identity = identity
        self.phone = phone
        self.total = total

    def show(self):
        print(self.pid, self.name, self.identity, self.phone, self.total)

    def save_c(self, DBw, blist, money):
        try:
            #money = input('输入存入钱数:')
            money = float(money)
        except:
            #print('数据类型错误')
            return 0
        self.total += float(money)
        DBw.DBcum(self)
        nowTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 现在
        new_bill = Bill(self.pid, '+' + str(money), nowTime, self.total)
        blist.append(new_bill)
        new_bill.show()
        DBw.DBbill(new_bill)
        print('存入成功!')
        return 1

    def draw_c(self, DBw, blist, money):
        try:
            #money = input('输入取出钱数:')
            money = float(money)
        except:
            #print('数据类型错误')
            return 0
        if self.total >= float(money):
            self.total -= float(money)
            DBw.DBcum(self)
            nowTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 现在
            new_bill = Bill(self.pid, '-' + str(money), nowTime, self.total)
            blist.append(new_bill)
            new_bill.show()
            DBw.DBbill(new_bill)
            print('取钱成功!')
            return 1
        else:
            print('余额不足,取款失败')
            return 0
        return 0

    def trans_c(self, DBw, clist, blist, pas, t_id, money):
        if self.password == pas:
            for cut in clist:
                if t_id == cut.pid:
                    try:
                        money = float(money)
                    except:
                        #print('数据类型错误')
                        return 0
                    if self.total >= float(money):
                        cut.total += float(money)
                        self.total -= float(money)
                        DBw.DBcum(cut)
                        DBw.DBcum(self)
                        nowTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 现在
                        new_bill = Bill(cut.pid, '+' + str(money), nowTime, cut.total)
                        blist.append(new_bill)
                        #new_bill.show()
                        DBw.DBbill(new_bill)
                        new_billsf = Bill(self.pid, '-' + str(money), nowTime, self.total)
                        blist.append(new_billsf)
                        new_billsf.show()
                        DBw.DBbill(new_billsf)
                        #print('转账成功!')
                        return 1
                    else:
                        #print('余额不足,转账失败')
                        return 0
            return 0
        #print('此账户不存在!')
        else:
            return 0

    def search_c(self, blist):
        table = list()
        for bill in blist:
            if self.pid == bill.pid:
                table.append(bill)
        return table

    def change_pasc(self, DBw, pas, new_pas, new_pas1):
        #pas = input('输入密码以确认信息:')
        if pas == self.password:
            #new_pas = input('输入新的密码:')
            #new_pas1 = input('请再输入一遍:')
            if new_pas == new_pas1:
                self.password = new_pas
                DBw.DBcum(self)
                #print('修改成功!')
                return 1
            else:
                #print('两个密码不一致,修改失败')
                return 0
        else:
            #print('密码错误,不允许修改')
            return 0

    def change_phe(self, DBw, pas, new_phe, new_phe1):
        #pas = input('输入密码以确认信息:')
        if pas == self.password:
            #new_phe = input('输入新的手机号:')
            #new_phe1 = input('请再输入一遍:')
            if new_phe == new_phe1:
                self.phone = new_phe
                DBw.DBcum(self)
                #print('修改成功!')
                return 1
            else:
                #print('两个手机号不一致,修改失败')
                return 0
        else:
            #print('密码错误,不允许修改')
            return 0


class Host(People):
    def __init__(self, pid, password, pflag):
        People.__init__(self, pid, password, pflag)

    def save_h(self, DBw, clist, blist, c_id, money):
        for cus in clist:
            if c_id == cus.pid:
                try:
                    money = float(money)
                except:
                    #QMessageBox.warning(self, "警告", "数据类型错误！", QMessageBox.Yes)
                    return 0
                cus.total += float(money)
                DBw.DBcum(cus)
                #QMessageBox.information(self, "成功", "存入成功！", QMessageBox.Yes)
                nowTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 现在
                new_bill = Bill(cus.pid, '+'+str(money), nowTime, cus.total)
                blist.append(new_bill)
                #new_bill.show()
                DBw.DBbill(new_bill)
                return 1
        #QMessageBox.warning(self, "警告", "此账户不存在！", QMessageBox.Yes)
        return 0

    def draw_h(self, DBw, clist, blist, c_id, c_pas, money):
        for cus in clist:
            if c_id == cus.pid and c_pas == cus.password:
                try:
                    money = float(money)
                except:
                    #QMessageBox.warning(self, "警告", "数据类型错误！", QMessageBox.Yes)
                    return 0
                if cus.total >= float(money):
                    cus.total -= float(money)
                    DBw.DBcum(cus)
                    #QMessageBox.information(self, "成功", "取钱成功！", QMessageBox.Yes)
                    nowTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 现在
                    new_bill = Bill(cus.pid, '-' + str(money), nowTime, cus.total)
                    blist.append(new_bill)
                    new_bill.show()
                    DBw.DBbill(new_bill)
                    return 1
                else:
                    #QMessageBox.warning(self, "警告", "余额不足！", QMessageBox.Yes)
                    return 0
        #QMessageBox.warning(self, "警告", "此账户不存在！或密码错误", QMessageBox.Yes)
        return 0

    def trans_h(self, DBw, clist, blist, c_id, c_pass, t_id, money):
        for cus in clist:
            if c_id == cus.pid:
                if cus.password == c_pass:
                    for cut in clist:
                        if t_id == cut.pid:
                            try:
                                money = float(money)
                            except:
                                #QMessageBox.warning(self, "警告", "数据类型错误！", QMessageBox.Yes)
                                return 0
                            if cus.total >= float(money):
                                cut.total += float(money)
                                cus.total -= float(money)
                                DBw.DBcum(cut)
                                DBw.DBcum(cus)
                                nowTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 现在
                                new_bill = Bill(cut.pid, '+' + str(money), nowTime, cut.total)
                                blist.append(new_bill)
                                #new_bill.show()
                                DBw.DBbill(new_bill)
                                new_billsf = Bill(cus.pid, '-' + str(money), nowTime, cus.total)
                                blist.append(new_billsf)
                                new_billsf.show()
                                DBw.DBbill(new_billsf)
                                #QMessageBox.information(self, "成功", "转账成功！", QMessageBox.Yes)
                                return 1
                            else:
                                #QMessageBox.warning(self, "警告", "余额不足！", QMessageBox.Yes)
                                return 0
                    else:
                        return 0
                else:
                    return 0
        #QMessageBox.warning(self, "警告", "账户不存在", QMessageBox.Yes)
        return 0

    def search_h(self, blist, c_id):
        table = list()
        for bill in blist:
            if c_id == bill.pid:
                table.append(bill)
        return table

        #QMessageBox.warning(self, "警告", "本账户暂无订单信息", QMessageBox.Yes)

    def rewrite(self, DBw, clist, c_id, pas, newname, newidentity, newphone, newtotal):
        for cus in clist:
            if c_id == cus.pid:
                if pas == cus.password:
                    #data = input('输入新的信息,包括姓名,身份证号码,电话,总存款等信息')
                    #s = data.split(',')
                    cus.name = newname
                    cus.identity = newidentity
                    cus.phone = newphone
                    cus.total = float(newtotal)
                    DBw.DBcum(cus)
                    DBw.DBdelBill(cus)
        #QMessageBox.information(self, "成功", "修改成功!", QMessageBox.Yes)
        return 1

    def change_pas(self, DBw, clist, c_id, pas, new_pas, new_pas1):
        for cus in clist:
            if c_id == cus.pid:
                if pas == cus.password:
                    if new_pas == new_pas1:
                        cus.password = new_pas
                        DBw.DBcum(cus)
                        #QMessageBox.information(self, "成功", "修改成功!", QMessageBox.Yes)
                        return 1
                    else:
                        #QMessageBox.warning(self, "警告", "两次密码不一致,修改失败", QMessageBox.Yes)
                        return 0
                else:
                    #QMessageBox.warning(self, "警告", "密码错误", QMessageBox.Yes)
                    return 0
        #QMessageBox.warning(self, "警告", "账户不存在", QMessageBox.Yes)
        return 0

    def cdelete(self, DBw, clist, blist, c_id, pas):
        for cus in clist:
            if c_id == cus.pid:
                if pas == cus.password:
                    #if d == 'y':
                    clist.remove(cus)
                    #倒序删除,无残留
                    for i in range(len(blist) - 1, -1, -1):
                        if blist[i].pid == c_id:
                            del blist[i]
                    DBw.DBdelcum(cus)
                    #QMessageBox.information(self, "成功", "销户成功!", QMessageBox.Yes)
                    return 1
                    #elif d == 'n':
                    #QMessageBox.information(self, "取消", "取消操作", QMessageBox.Yes)
                    #return
                else:
                    #QMessageBox.warning(self, "警告", "密码错误,操作失败", QMessageBox.Yes)
                    return 0
        #QMessageBox.warning(self, "警告", "用户不存在", QMessageBox.Yes)
        return 0

